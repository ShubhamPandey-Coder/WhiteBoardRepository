package com.amdocs.mecbrowsertool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MecBrowserToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
